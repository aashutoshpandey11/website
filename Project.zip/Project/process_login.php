<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve username and password from the form
    $username = $_POST["username"];
    $password = $_POST["password"];

    // In a real-world scenario, you should validate the credentials against a database
    // For simplicity, let's assume valid credentials for this example
    $validUsername = "user123";
    $validPassword = "password123";

    // Check if the entered credentials are valid
    if ($username == $validUsername && $password == $validPassword) {
        // Redirect to a success page or perform further actions
        header("Location: success.php");
        exit();
    } else {
        // Invalid credentials, redirect to a login error page
        header("Location: login_error.php");
        exit();
    }
} else {
    // If the form is not submitted, redirect to the login page
    header("Location: index.html");
    exit();
}
?>
